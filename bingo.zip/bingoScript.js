function nBox(id,row,col){
    this.id=id;
    this.row=row;
    this.col=col;
    this.state=false;
}
function generateNewCard(){
    document.getElementById("win").innerHTML="";
    checkTiles();
    for(var i=1;i<=25;i++){
        let b=document.getElementById("box"+i);
        b.style.backgroundColor="pink";
        if(i!=13){
        document.getElementById("box"+i).innerHTML= "<p>"+Math.floor(Math.random()*25+1)+"</p>";
    }
    }
}
function checkTiles(){
   let r1=0;
   let r2=0;
   let r3=0;
   let r4=0;
   let r5=0;
   let c1=0;
   let c2=0;
   let c3=0;
   let c4=0;
   let c5=0;
    let b1= document.getElementById("box1");
    bx1= new nBox(b1,1,1);
    b1.onclick=function(){
        bx1.state=!bx1.state;
        if(bx1.state==true){
        b1.style.backgroundColor="yellow";
        r1++;
        c1++;
        }
        else{
            b1.style.backgroundColor="pink";
            r1--;
            c1--;
        }
        if(r1>=5||c1>=5){
        document.getElementById("win").innerHTML="Bingo!";
        }
        if(bx1.state==true&&bx7.state==true&&bx13.state==true&&bx19.state==true&&bx25.state==true){
            document.getElementById("win").innerHTML="Bingo!";
        }
    }
    let b2= document.getElementById("box2");
    bx2= new nBox(b2,1,2);
    b2.onclick=function(){
        bx2.state=!bx2.state;
        if(bx2.state==true){
        b2.style.backgroundColor="yellow";
        r1++;
        c2++;
        }
        else{
            b2.style.backgroundColor="pink";
            r1--;
            c2--;
        }
        if(r1>=5||c2>=5){
            document.getElementById("win").innerHTML="Bingo!";
            }
    }
    let b3= document.getElementById("box3");
    bx3= new nBox(b3,1,3);
    b3.onclick=function(){
        bx3.state=!bx3.state;
        if(bx3.state==true){
        b3.style.backgroundColor="yellow";
        r1++;
        c3++;
        }
        else{
            b3.style.backgroundColor="pink";
            r1--;
            c3--;
        }
        if(r1>=5||c3>=5){
            document.getElementById("win").innerHTML="Bingo!";
            }
    }
    let b4= document.getElementById("box4");
    bx4= new nBox(b4,1,4);
    b4.onclick=function(){
        bx4.state=!bx4.state;
        if(bx4.state==true){
        b4.style.backgroundColor="yellow";
        r1++;
        c4++;
        }
        else{
            b4.style.backgroundColor="pink";
            r1--;
            c4--;
        }
        if(r1>=5||c4>=5){
            document.getElementById("win").innerHTML="Bingo!";
            }
    }
    let b5= document.getElementById("box5");
    bx5= new nBox(b5,1,5);
    b5.onclick=function(){
        bx5.state=!bx5.state;
        if(bx5.state==true){
        b5.style.backgroundColor="yellow";
        r1++;
        c5++;
        }
        else{
            b5.style.backgroundColor="pink";
            r1--;
            c5--;
        }
        if(r1>=5||c5>=5){
            document.getElementById("win").innerHTML="Bingo!";
            }
            if(bx5.state==true&&bx9.state==true&&bx13.state==true&&bx17.state==true&&bx21.state==true){
                document.getElementById("win").innerHTML="Bingo!";
            }
    }
    let b6= document.getElementById("box6");
    bx6= new nBox(b6,2,1);
    b6.onclick=function(){
        bx6.state=!bx6.state;
        if(bx6.state==true){
        b6.style.backgroundColor="yellow";
        r2++;
        c1++;
        }
        else{
            b6.style.backgroundColor="pink";
            r2--;
            c1--;
        }
        if(r2>=5||c1>=5){
            document.getElementById("win").innerHTML="Bingo!";
            }
    }
    let b7= document.getElementById("box7");
    bx7= new nBox(b7,2,2);
    b7.onclick=function(){
        bx7.state=!bx7.state;
        if(bx7.state==true){
        b7.style.backgroundColor="yellow";
        r2++;
        c2++;
        }
        else{
            b7.style.backgroundColor="pink";
        r2--;
        c2--;
        }
        if(r2>=5||c2>=5){
            document.getElementById("win").innerHTML="Bingo!";
            }
            if(bx1.state==true&&bx7.state==true&&bx13.state==true&&bx19.state==true&&bx25.state==true){
                document.getElementById("win").innerHTML="Bingo!";
            }
    }
    let b8= document.getElementById("box8");
    bx8= new nBox(b8,2,3);
    b8.onclick=function(){
        bx8.state=!bx8.state;
        if(bx8.state==true){
        b8.style.backgroundColor="yellow";
        r2++;
        c3++;
        }
        else{
            b8.style.backgroundColor="pink";
        r2--;
        c3--;
        }   
        if(r2>=5||c3>=5){
            document.getElementById("win").innerHTML="Bingo!";
            } }
    let b9= document.getElementById("box9");
    bx9= new nBox(b9,2,4);
    b9.onclick=function(){
        bx9.state=!bx9.state;
        if(bx9.state==true){
        b9.style.backgroundColor="yellow";
        r2++;
        c4++;
        }
        else{
            b9.style.backgroundColor="pink";
        r2--;
        c4--;
        }
        if(r2>=5||c4>=5){
            document.getElementById("win").innerHTML="Bingo!";
            }
            if(bx5.state==true&&bx9.state==true&&bx13.state==true&&bx17.state==true&&bx21.state==true){
                document.getElementById("win").innerHTML="Bingo!";
            }
    }
    let b10= document.getElementById("box10");
    bx10= new nBox(b10,2,5);
    b10.onclick=function(){
        bx10.state=!bx10.state;
        if(bx10.state==true){
        b10.style.backgroundColor="yellow";
        r2++;
        c5++;
        }
        else{
            b10.style.backgroundColor="pink";
            r2--;
            c5--;
        }  
        if(r2>=5||c5>=5){
            document.getElementById("win").innerHTML="Bingo!";
            }
    }
    let b11= document.getElementById("box11");
    bx11= new nBox(b11,3,1);
    b11.onclick=function(){
        bx11.state=!bx11.state;
        if(bx11.state==true){
        b11.style.backgroundColor="yellow";
        r3++;
        c1++;
        }
        else{
            b11.style.backgroundColor="pink";
            r3--;
            c1--;
        }   
        if(r3>=5||c1>=5){
            document.getElementById("win").innerHTML="Bingo!";
            }
         }
    let b12= document.getElementById("box12");
    bx12= new nBox(b12,3,2);
    b12.onclick=function(){
        bx12.state=!bx12.state;
        if(bx12.state==true){
        b12.style.backgroundColor="yellow";
        r3++;
        c2++;
        }
        else{
            b12.style.backgroundColor="pink";
            r3--;
            c2--;
        }   
        if(r3>=5||c2>=5){
            document.getElementById("win").innerHTML="Bingo!";
            }
    }
    let b13= document.getElementById("box13");
    bx13= new nBox(b13,3,3);
    b13.onclick=function(){
        bx13.state=!bx13.state;
        if(bx13.state==true){
        b13.style.backgroundColor="yellow";
        r3++;
        c3++;
        }
        else{
            b13.style.backgroundColor="pink";
            r3--;
            c3--;
        }   
        if(r3>=5||c3>=5){
            document.getElementById("win").innerHTML="Bingo!";
            }
            if(bx1.state==true&&bx7.state==true&&bx13.state==true&&bx19.state==true&&bx25.state==true){
                document.getElementById("win").innerHTML="Bingo!";
            }
            if(bx5.state==true&&bx9.state==true&&bx13.state==true&&bx17.state==true&&bx21.state==true){
                document.getElementById("win").innerHTML="Bingo!";
            }
    }
    let b14= document.getElementById("box14");
    bx14= new nBox(b14,3,4);
    b14.onclick=function(){
        bx14.state=!bx14.state;
        if(bx14.state==true){
        b14.style.backgroundColor="yellow";
        r3++;
        c4++;
        }
        else{
            b14.style.backgroundColor="pink";
        r3--;
        c4--;
        }   
        if(r3>=5||c4>=5){
            document.getElementById("win").innerHTML="Bingo!";
            }
    }
    let b15= document.getElementById("box15");
    bx15= new nBox(b15,3,5);
    b15.onclick=function(){
        bx15.state=!bx15.state;
        if(bx15.state==true){
        b15.style.backgroundColor="yellow";
        r3++;
        c5++;
        }
        else{
            b15.style.backgroundColor="pink";
        r3--;
        c5--;
        }  
        if(r3>=5||c5>=5){
            document.getElementById("win").innerHTML="Bingo!";
            }
    }
    let b16= document.getElementById("box16");
    bx16= new nBox(b16,4,1);
    b16.onclick=function(){
        bx16.state=!bx16.state;
        if(bx16.state==true){
        b16.style.backgroundColor="yellow";
        r4++;
        c1++;
        }
        else{
            b16.style.backgroundColor="pink";
            r4--;
            c1--;
        }   
        if(r4>=5||c1>=5){
            document.getElementById("win").innerHTML="Bingo!";
            }
    }
    let b17= document.getElementById("box17");
    bx17= new nBox(b17,4,2);
    b17.onclick=function(){
        bx17.state=!bx17.state;
        if(bx17.state==true){
        b17.style.backgroundColor="yellow";
        r4++;
        c2++;
        }
        else{
            b17.style.backgroundColor="pink";
            r4--;
            c2--;
        }    
        if(r4>=5||c2>=5){
            document.getElementById("win").innerHTML="Bingo!";
            }
            if(bx5.state==true&&bx9.state==true&&bx13.state==true&&bx17.state==true&&bx21.state==true){
                document.getElementById("win").innerHTML="Bingo!";
            }
    }
    let b18= document.getElementById("box18");
    bx18= new nBox(b18,4,3);
    b18.onclick=function(){
        bx18.state=!bx18.state;
        if(bx18.state==true){
        b18.style.backgroundColor="yellow";
        r4++;
        c3++;
        }
        else{
            b18.style.backgroundColor="pink";
            r4--;
            c3--;
        }   
        if(r4>=5||c3>=5){
            document.getElementById("win").innerHTML="Bingo!";
            }
    }
    let b19= document.getElementById("box19");
    bx19= new nBox(b19,4,4);
    b19.onclick=function(){
        bx19.state=!bx19.state;
        if(bx19.state==true){
        b19.style.backgroundColor="yellow";
        r4++;
        c4++;
        }
        else{
            b19.style.backgroundColor="pink";
            r4--;
            c4--;
        }    
        if(r4>=5||c4>=5){
            document.getElementById("win").innerHTML="Bingo!";
            }
            if(bx1.state==true&&bx7.state==true&&bx13.state==true&&bx19.state==true&&bx25.state==true){
                document.getElementById("win").innerHTML="Bingo!";
            }
    }
    let b20= document.getElementById("box20");
    bx20= new nBox(b20,4,5);
    b20.onclick=function(){
        bx20.state=!bx20.state;
        if(bx20.state==true){
        b20.style.backgroundColor="yellow";
        r4++;
        c5++;
        }
        else{
            b20.style.backgroundColor="pink";
            r4--;
            c5--;
        }  
    
        if(r4>=5||c5>=5){
            document.getElementById("win").innerHTML="Bingo!";
            }}
    let b21= document.getElementById("box21");
    bx21= new nBox(b21,5,1);
    b21.onclick=function(){
        bx21.state=!bx21.state;
        if(bx21.state==true){
        b21.style.backgroundColor="yellow";
        r5++;
        c1++;
        }
        else{
            b21.style.backgroundColor="pink";
            r5--;
            c1--;
        }    
    
        if(r5>=5||c1>=5){
            document.getElementById("win").innerHTML="Bingo!";
            }
            if(bx5.state==true&&bx9.state==true&&bx13.state==true&&bx17.state==true&&bx21.state==true){
                document.getElementById("win").innerHTML="Bingo!";
            }}
    let b22= document.getElementById("box22");
    bx22= new nBox(b22,5,2);
    b22.onclick=function(){
        bx22.state=!bx22.state;
        if(bx22.state==true){
        b22.style.backgroundColor="yellow";
        r5++;
        c2++;
        }
        else{
            b22.style.backgroundColor="pink";
            r5--;
            c2--;
        }   
        if(r5>=5||c2>=5){
            document.getElementById("win").innerHTML="Bingo!";
            } }
    let b23= document.getElementById("box23");
    bx23= new nBox(b23,5,3);
    b23.onclick=function(){
        bx23.state=!bx23.state;
        if(bx23.state==true){
        b23.style.backgroundColor="yellow";
        r5++;
        c3++;
        }
        else{
            b23.style.backgroundColor="pink";
            r5--;
            c3--;
        }    
        if(r5>=5||c3>=5){
            document.getElementById("win").innerHTML="Bingo!";
            }}
    let b24= document.getElementById("box24");
    bx24= new nBox(b24,5,4);
    b24.onclick=function(){
        bx24.state=!bx24.state;
        if(bx24.state==true){
        b24.style.backgroundColor="yellow";
        r5++;
        c4++;
        }
        else{
            b24.style.backgroundColor="pink";
            r5--;
            c4--;
        }   
        if(r5>=5||c4>=5){
            document.getElementById("win").innerHTML="Bingo!";
            } }
    let b25= document.getElementById("box25");
    bx25= new nBox(b25,5,5);
    b25.onclick=function(){
        bx25.state=!bx25.state;
        if(bx25.state==true){
        b25.style.backgroundColor="yellow";
        r5++;
        c5++;
        }
        else{
            b25.style.backgroundColor="pink";
            r5--;
            c5--;
        }   
        if(r5>=5||c5>=5){
            document.getElementById("win").innerHTML="Bingo!";
            }
            if(bx1.state==true&&bx7.state==true&&bx13.state==true&&bx19.state==true&&bx25.state==true){
                document.getElementById("win").innerHTML="Bingo!";
            } }
 
   
}
window.onload = function(){
   checkTiles();
}